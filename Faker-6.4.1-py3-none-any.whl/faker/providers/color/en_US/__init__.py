from .. import Provider as ColorProvider


class Provider(ColorProvider):
    """Implement color provider for ``en_US`` locale."""

    pass
