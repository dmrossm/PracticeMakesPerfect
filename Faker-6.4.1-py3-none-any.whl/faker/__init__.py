from faker.factory import Factory
from faker.generator import Generator
from faker.proxy import Faker

VERSION = '6.4.1'

__all__ = ('Factory', 'Generator', 'Faker')
